Fill this directory
===================

I didn't want to include Google's fonts, because it is easy and free to get them. In that way I don't have to worry about license and stuff.

See [this blog post](http://drlog.andregoerres.de/use-truetype-fonts-with-latex/) for instructions or just go to [Google Web Fonts](http://www.google.com/fonts/), select the fonts you want and download via the little arrow button on the top right. Extract the contents of the `.zip` and move the `.ttf` files in this directory.
Then you are ready to use them.
